<?php
require '../config.php';

$page_title = 'Contacto';
$include = 'contacto';

require '../includes/layout.php';
