<img src="<?php echo $web_path; ?>images/auto.jpg" />
