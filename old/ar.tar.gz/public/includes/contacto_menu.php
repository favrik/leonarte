                    <li>
                        <a href="<?php echo $web_path; ?>contacto/" title="Contacto">
                            <img src="<?php echo $web_path; ?>images/contacto.jpg" alt="Contacto" />
                        </a>

                        <p>
                            <a href="mailto:minervaesquer@leonarte.com">minervaesquer@leonarte.com</a>
                        </p>
                    </li>
