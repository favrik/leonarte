<?php
require 'config.php';

$page_title = 'Inicio';
$include = 'home';

require 'includes/layout.php';
